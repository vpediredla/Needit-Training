# Generated automatically -- do not modify!    -*- buffer-read-only: t -*-
VERSION = "2.5.6"
